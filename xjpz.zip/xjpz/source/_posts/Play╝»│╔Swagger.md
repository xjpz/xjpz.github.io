---
title: Play集成Swagger
date: 2016-11-06 15:40:00
tags: [play-swagger,swagger-ui]
categories: Play
---

> Swagger 是一款RESTFUL接口的文档在线自动生成+功能测试功能软件。

`Swagger`是免费开源的，简单易用，较好的解决文档与代码不同步的问题，对接口开发者开发测试、前端人员开发联调都非常方便，点击就能调用接口而不必再去借助`Postman`工具，而且能够非常方便集成在`Play`中，无论是`Scala`版还是`Java`版Play。

集成在play中也很简单，以下以Play for Java版为例。

### 导入jar包，

	"io.swagger" %% "swagger-play2" % "1.5.3"

### 导入swagger-ui

![enter image description here]( /uploads/o_swagger-play1.png)


### 配置swagger-index页面

这里直接将`swagger-ui`里的`index.html`内容放到`views/main.scala.html`中，页面中引入的css、js文件地址改成play方式。

### 配置路由

![enter image description here]( /uploads/o_swagger-play4.png)

### 汉化
在`main.scala.html`中引入相关js文件即可，

![enter image description here](/uploads/o_swagger-play2.png)

### 设置Token

#### 在Header中添加Token

![enter image description here](/uploads/o_swagger-play3.png)

#### 在url中添加token
只需将`ApiKeyAuthorization`中`header`改为`query`即可。

### 代码集成

![enter image description here](/uploads/o_swagger-play5.png)

### 效果

GET请求

![enter image description here](/uploads/o_swagger-play6.png)

POST请求

![enter image description here](/uploads/o_swagger-play7.png)

点击试一下之后

![enter image description here](/uploads/o_swagger-play8.png)

[Github源码:https://github.com/xjpz/play-java-swagger](https://github.com/xjpz/play-java-swagger)