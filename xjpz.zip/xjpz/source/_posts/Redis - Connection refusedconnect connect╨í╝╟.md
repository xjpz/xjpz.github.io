layout: 
title: Redis - Connection refused:connect connect 小记
date: 2016-09-29 10:59:47
tags: [redis connect]
categories: 其他
---

## Q: 

将代码迁移到新服务器上运行报错：

`Could not get a resource from the pool`

在服务器上能ping通，在本地根本就无法连接 或者：

`Connection refused: connect`

## A: 

需将 redis配置 

 - `bind 127.0.0.1` 注释
 - `protected-mode yes` 改为 `protected-mode no`
