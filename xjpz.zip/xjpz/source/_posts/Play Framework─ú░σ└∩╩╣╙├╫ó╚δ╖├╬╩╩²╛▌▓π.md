---
title: PlayFramework模板里使用注入访问数据层
date: 2016-09-09 16:03:57
tags: [PlayFramework,模板注入,数据层]
categories: Play
---

从Play2.4开始，推荐使用依赖注入替代静态控制器。因此我们不能像play2.3那样，在模板里直接调用object访问数据层。是的，我们还是可以使用常规方式，通过传参到模板里。不过这样很多时候不方便，比如当参数很多得时候，写起来麻烦，写出来的代码也很不好看。所以我就想在模板里直接访问数据层。

其实实现起来也很简单，定义数据层那就不说了。


### 创建 MessageServices 调用数据层


	class MessageServices @Inject()(messages: Messages) {

		def retrieve(id:Long) = Await.result(messages.retrieve(id),Duration.Inf)

	}


### 创建ViewAccessPoint 方便模板调用

	object ViewAccessPoint {
		private val myDaoCache = Application.instanceCache[MessageServices]

		object Implicits {
			implicit def myDao(implicit application: Application): MessageServices = myDaoCache(application)
		}
	}

### html模板


	@import services.ViewAccessPoint.Implicits._
	@import play.api.Play.current
	@(id:Long)
	<!DOCTYPE html>
	<html lang="en">
	<head>
	  <meta charset="UTF-8">
	  <title>Title</title>
	</head>
	<body>

	  <p>
		  @defining(myDao.retrieve(id)){ mood =>
			@mood.get.content
		  }
	  </p>

	</body>

	
[源码：https://github.com/xjpz/play-view](https://github.com/xjpz/play-view)